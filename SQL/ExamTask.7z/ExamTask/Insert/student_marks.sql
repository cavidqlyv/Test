USE examtask 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-01', 
  8 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-04', 
  11 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-05', 
  4 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-11', 
  6 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-15', 
  1 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-20', 
  9 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-21', 
  2 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-23', 
  11 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-27', 
  3 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-28', 
  12 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-29', 
  5 

EXECUTE dbo.Insert_student_marks 
  1, 
  '2018-08-30', 
  5 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-05', 
  3 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-06', 
  9 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-10', 
  6 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-13', 
  6 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-18', 
  7 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-23', 
  4 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-24', 
  5 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-25', 
  4 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-26', 
  11 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-28', 
  11 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-29', 
  3 

EXECUTE dbo.Insert_student_marks 
  2, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-03', 
  7 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-04', 
  3 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-06', 
  8 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-08', 
  11 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-09', 
  5 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-10', 
  8 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-12', 
  4 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-14', 
  9 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-15', 
  2 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-18', 
  3 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-19', 
  7 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-20', 
  11 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-22', 
  5 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-24', 
  2 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-27', 
  1 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-28', 
  4 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  3, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-03', 
  5 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-06', 
  2 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-07', 
  2 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-08', 
  5 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-13', 
  5 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-14', 
  5 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-15', 
  7 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-16', 
  12 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-22', 
  7 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-25', 
  11 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  4, 
  '2018-08-30', 
  9 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-03', 
  12 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-04', 
  4 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-06', 
  6 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-07', 
  9 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-08', 
  9 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-09', 
  4 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-10', 
  5 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-14', 
  12 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-19', 
  4 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-20', 
  4 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-23', 
  10 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-27', 
  9 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  5, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-02', 
  2 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-03', 
  8 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-05', 
  7 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-07', 
  4 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-09', 
  1 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-10', 
  7 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-12', 
  11 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-13', 
  1 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-14', 
  11 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-17', 
  11 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-19', 
  1 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-21', 
  9 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-23', 
  8 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-25', 
  5 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-29', 
  12 

EXECUTE dbo.Insert_student_marks 
  6, 
  '2018-08-30', 
  4 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-01', 
  6 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-03', 
  6 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-05', 
  1 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-08', 
  2 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-10', 
  9 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-11', 
  7 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-12', 
  5 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-15', 
  4 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-17', 
  5 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-18', 
  11 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-20', 
  10 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-21', 
  11 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-24', 
  8 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-25', 
  3 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-26', 
  5 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-28', 
  8 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-29', 
  11 

EXECUTE dbo.Insert_student_marks 
  7, 
  '2018-08-30', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-01', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-02', 
  7 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-03', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-05', 
  11 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-06', 
  11 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-07', 
  8 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-08', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-10', 
  12 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-11', 
  4 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-13', 
  2 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-15', 
  5 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-17', 
  9 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-19', 
  12 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-22', 
  3 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-28', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  8, 
  '2018-08-30', 
  8 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-01', 
  4 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-02', 
  8 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-03', 
  10 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-04', 
  5 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-05', 
  8 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-06', 
  12 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-07', 
  1 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-11', 
  12 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-14', 
  10 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-18', 
  10 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-19', 
  6 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-20', 
  12 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-22', 
  2 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-23', 
  3 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-26', 
  2 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  9, 
  '2018-08-30', 
  6 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-03', 
  4 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-04', 
  12 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-12', 
  1 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-15', 
  9 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-16', 
  7 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-17', 
  12 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-20', 
  5 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-21', 
  10 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-23', 
  1 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-24', 
  11 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-28', 
  2 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-29', 
  2 

EXECUTE dbo.Insert_student_marks 
  10, 
  '2018-08-30', 
  2 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-01', 
  8 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-04', 
  11 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-05', 
  4 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-11', 
  6 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-15', 
  1 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-20', 
  9 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-21', 
  2 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-23', 
  11 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-27', 
  3 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-28', 
  12 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-29', 
  5 

EXECUTE dbo.Insert_student_marks 
  11, 
  '2018-08-30', 
  5 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-05', 
  3 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-06', 
  9 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-10', 
  6 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-13', 
  6 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-18', 
  7 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-23', 
  4 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-24', 
  5 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-25', 
  4 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-26', 
  11 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-28', 
  11 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-29', 
  3 

EXECUTE dbo.Insert_student_marks 
  12, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-03', 
  7 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-04', 
  3 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-06', 
  8 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-08', 
  11 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-09', 
  5 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-10', 
  8 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-12', 
  4 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-14', 
  9 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-15', 
  2 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-18', 
  3 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-19', 
  7 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-20', 
  11 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-22', 
  5 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-24', 
  2 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-27', 
  1 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-28', 
  4 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  13, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-03', 
  5 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-06', 
  2 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-07', 
  2 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-08', 
  5 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-13', 
  5 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-14', 
  5 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-15', 
  7 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-16', 
  12 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-22', 
  7 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-25', 
  11 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  14, 
  '2018-08-30', 
  9 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-03', 
  12 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-04', 
  4 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-06', 
  6 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-07', 
  9 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-08', 
  9 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-09', 
  4 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-10', 
  5 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-14', 
  12 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-19', 
  4 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-20', 
  4 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-23', 
  10 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-27', 
  9 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  15, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-02', 
  2 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-03', 
  8 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-05', 
  7 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-07', 
  4 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-09', 
  1 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-10', 
  7 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-12', 
  11 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-13', 
  1 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-14', 
  11 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-17', 
  11 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-19', 
  1 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-21', 
  9 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-23', 
  8 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-25', 
  5 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-29', 
  12 

EXECUTE dbo.Insert_student_marks 
  16, 
  '2018-08-30', 
  4 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-01', 
  6 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-03', 
  6 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-05', 
  1 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-08', 
  2 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-10', 
  9 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-11', 
  7 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-12', 
  5 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-15', 
  4 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-17', 
  5 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-18', 
  11 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-20', 
  10 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-21', 
  11 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-24', 
  8 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-25', 
  3 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-26', 
  5 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-28', 
  8 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-29', 
  11 

EXECUTE dbo.Insert_student_marks 
  17, 
  '2018-08-30', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-01', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-02', 
  7 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-03', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-05', 
  11 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-06', 
  11 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-07', 
  8 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-08', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-10', 
  12 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-11', 
  4 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-13', 
  2 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-15', 
  5 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-17', 
  9 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-19', 
  12 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-22', 
  3 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-28', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  18, 
  '2018-08-30', 
  8 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-01', 
  4 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-02', 
  8 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-03', 
  10 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-04', 
  5 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-05', 
  8 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-06', 
  12 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-07', 
  1 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-11', 
  12 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-14', 
  10 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-18', 
  10 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-19', 
  6 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-20', 
  12 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-22', 
  2 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-23', 
  3 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-26', 
  2 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  19, 
  '2018-08-30', 
  6 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-03', 
  4 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-04', 
  12 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-12', 
  1 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-15', 
  9 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-16', 
  7 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-17', 
  12 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-20', 
  5 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-21', 
  10 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-23', 
  1 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-24', 
  11 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-28', 
  2 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-29', 
  2 

EXECUTE dbo.Insert_student_marks 
  20, 
  '2018-08-30', 
  2 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-01', 
  8 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-04', 
  11 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-05', 
  4 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-11', 
  6 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-15', 
  1 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-20', 
  9 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-21', 
  2 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-23', 
  11 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-27', 
  3 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-28', 
  12 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-29', 
  5 

EXECUTE dbo.Insert_student_marks 
  21, 
  '2018-08-30', 
  5 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-05', 
  3 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-06', 
  9 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-10', 
  6 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-13', 
  6 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-18', 
  7 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-23', 
  4 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-24', 
  5 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-25', 
  4 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-26', 
  11 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-28', 
  11 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-29', 
  3 

EXECUTE dbo.Insert_student_marks 
  22, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-03', 
  7 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-04', 
  3 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-06', 
  8 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-08', 
  11 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-09', 
  5 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-10', 
  8 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-12', 
  4 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-14', 
  9 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-15', 
  2 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-18', 
  3 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-19', 
  7 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-20', 
  11 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-22', 
  5 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-24', 
  2 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-27', 
  1 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-28', 
  4 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  23, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-03', 
  5 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-06', 
  2 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-07', 
  2 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-08', 
  5 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-13', 
  5 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-14', 
  5 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-15', 
  7 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-16', 
  12 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-22', 
  7 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-25', 
  11 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  24, 
  '2018-08-30', 
  9 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-03', 
  12 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-04', 
  4 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-06', 
  6 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-07', 
  9 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-08', 
  9 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-09', 
  4 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-10', 
  5 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-14', 
  12 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-19', 
  4 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-20', 
  4 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-23', 
  10 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-27', 
  9 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  25, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-02', 
  2 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-03', 
  8 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-05', 
  7 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-07', 
  4 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-09', 
  1 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-10', 
  7 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-12', 
  11 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-13', 
  1 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-14', 
  11 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-17', 
  11 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-19', 
  1 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-21', 
  9 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-23', 
  8 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-25', 
  5 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-29', 
  12 

EXECUTE dbo.Insert_student_marks 
  26, 
  '2018-08-30', 
  4 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-01', 
  6 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-03', 
  6 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-05', 
  1 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-08', 
  2 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-10', 
  9 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-11', 
  7 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-12', 
  5 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-15', 
  4 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-17', 
  5 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-18', 
  11 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-20', 
  10 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-21', 
  11 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-24', 
  8 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-25', 
  3 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-26', 
  5 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-28', 
  8 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-29', 
  11 

EXECUTE dbo.Insert_student_marks 
  27, 
  '2018-08-30', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-01', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-02', 
  7 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-03', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-05', 
  11 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-06', 
  11 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-07', 
  8 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-08', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-10', 
  12 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-11', 
  4 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-13', 
  2 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-15', 
  5 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-17', 
  9 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-19', 
  12 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-22', 
  3 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-28', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  28, 
  '2018-08-30', 
  8 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-01', 
  4 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-02', 
  8 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-03', 
  10 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-04', 
  5 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-05', 
  8 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-06', 
  12 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-07', 
  1 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-11', 
  12 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-14', 
  10 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-18', 
  10 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-19', 
  6 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-20', 
  12 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-22', 
  2 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-23', 
  3 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-26', 
  2 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  29, 
  '2018-08-30', 
  6 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-03', 
  4 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-04', 
  12 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-12', 
  1 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-15', 
  9 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-16', 
  7 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-17', 
  12 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-20', 
  5 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-21', 
  10 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-23', 
  1 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-24', 
  11 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-28', 
  2 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-29', 
  2 

EXECUTE dbo.Insert_student_marks 
  30, 
  '2018-08-30', 
  2 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-01', 
  8 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-04', 
  11 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-05', 
  4 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-11', 
  6 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-15', 
  1 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-20', 
  9 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-21', 
  2 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-23', 
  11 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-27', 
  3 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-28', 
  12 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-29', 
  5 

EXECUTE dbo.Insert_student_marks 
  31, 
  '2018-08-30', 
  5 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-05', 
  3 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-06', 
  9 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-10', 
  6 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-13', 
  6 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-18', 
  7 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-23', 
  4 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-24', 
  5 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-25', 
  4 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-26', 
  11 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-28', 
  11 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-29', 
  3 

EXECUTE dbo.Insert_student_marks 
  32, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-03', 
  7 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-04', 
  3 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-06', 
  8 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-08', 
  11 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-09', 
  5 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-10', 
  8 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-12', 
  4 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-14', 
  9 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-15', 
  2 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-18', 
  3 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-19', 
  7 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-20', 
  11 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-22', 
  5 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-24', 
  2 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-27', 
  1 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-28', 
  4 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  33, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-03', 
  5 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-06', 
  2 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-07', 
  2 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-08', 
  5 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-13', 
  5 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-14', 
  5 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-15', 
  7 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-16', 
  12 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-22', 
  7 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-25', 
  11 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  34, 
  '2018-08-30', 
  9 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-03', 
  12 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-04', 
  4 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-06', 
  6 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-07', 
  9 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-08', 
  9 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-09', 
  4 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-10', 
  5 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-14', 
  12 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-19', 
  4 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-20', 
  4 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-23', 
  10 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-27', 
  9 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  35, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-02', 
  2 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-03', 
  8 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-05', 
  7 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-07', 
  4 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-09', 
  1 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-10', 
  7 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-12', 
  11 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-13', 
  1 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-14', 
  11 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-17', 
  11 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-19', 
  1 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-21', 
  9 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-23', 
  8 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-25', 
  5 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-29', 
  12 

EXECUTE dbo.Insert_student_marks 
  36, 
  '2018-08-30', 
  4 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-01', 
  6 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-03', 
  6 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-05', 
  1 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-08', 
  2 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-10', 
  9 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-11', 
  7 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-12', 
  5 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-15', 
  4 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-17', 
  5 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-18', 
  11 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-20', 
  10 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-21', 
  11 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-24', 
  8 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-25', 
  3 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-26', 
  5 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-28', 
  8 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-29', 
  11 

EXECUTE dbo.Insert_student_marks 
  37, 
  '2018-08-30', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-01', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-02', 
  7 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-03', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-05', 
  11 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-06', 
  11 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-07', 
  8 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-08', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-10', 
  12 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-11', 
  4 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-13', 
  2 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-15', 
  5 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-17', 
  9 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-19', 
  12 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-22', 
  3 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-28', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  38, 
  '2018-08-30', 
  8 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-01', 
  4 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-02', 
  8 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-03', 
  10 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-04', 
  5 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-05', 
  8 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-06', 
  12 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-07', 
  1 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-11', 
  12 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-14', 
  10 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-18', 
  10 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-19', 
  6 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-20', 
  12 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-22', 
  2 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-23', 
  3 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-26', 
  2 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  39, 
  '2018-08-30', 
  6 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-03', 
  4 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-04', 
  12 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-12', 
  1 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-15', 
  9 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-16', 
  7 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-17', 
  12 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-20', 
  5 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-21', 
  10 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-23', 
  1 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-24', 
  11 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-28', 
  2 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-29', 
  2 

EXECUTE dbo.Insert_student_marks 
  40, 
  '2018-08-30', 
  2 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-01', 
  8 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-04', 
  11 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-05', 
  4 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-11', 
  6 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-15', 
  1 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-20', 
  9 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-21', 
  2 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-23', 
  11 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-27', 
  3 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-28', 
  12 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-29', 
  5 

EXECUTE dbo.Insert_student_marks 
  41, 
  '2018-08-30', 
  5 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-05', 
  3 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-06', 
  9 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-10', 
  6 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-13', 
  6 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-18', 
  7 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-23', 
  4 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-24', 
  5 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-25', 
  4 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-26', 
  11 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-28', 
  11 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-29', 
  3 

EXECUTE dbo.Insert_student_marks 
  42, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-03', 
  7 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-04', 
  3 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-06', 
  8 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-08', 
  11 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-09', 
  5 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-10', 
  8 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-12', 
  4 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-14', 
  9 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-15', 
  2 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-18', 
  3 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-19', 
  7 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-20', 
  11 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-22', 
  5 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-24', 
  2 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-27', 
  1 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-28', 
  4 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  43, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-03', 
  5 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-06', 
  2 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-07', 
  2 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-08', 
  5 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-13', 
  5 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-14', 
  5 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-15', 
  7 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-16', 
  12 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-22', 
  7 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-25', 
  11 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  44, 
  '2018-08-30', 
  9 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-03', 
  12 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-04', 
  4 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-06', 
  6 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-07', 
  9 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-08', 
  9 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-09', 
  4 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-10', 
  5 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-14', 
  12 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-19', 
  4 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-20', 
  4 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-23', 
  10 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-27', 
  9 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  45, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-02', 
  2 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-03', 
  8 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-05', 
  7 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-07', 
  4 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-09', 
  1 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-10', 
  7 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-12', 
  11 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-13', 
  1 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-14', 
  11 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-17', 
  11 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-19', 
  1 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-21', 
  9 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-23', 
  8 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-25', 
  5 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-29', 
  12 

EXECUTE dbo.Insert_student_marks 
  46, 
  '2018-08-30', 
  4 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-01', 
  6 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-03', 
  6 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-05', 
  1 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-08', 
  2 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-10', 
  9 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-11', 
  7 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-12', 
  5 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-15', 
  4 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-17', 
  5 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-18', 
  11 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-20', 
  10 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-21', 
  11 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-24', 
  8 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-25', 
  3 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-26', 
  5 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-28', 
  8 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-29', 
  11 

EXECUTE dbo.Insert_student_marks 
  47, 
  '2018-08-30', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-01', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-02', 
  7 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-03', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-05', 
  11 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-06', 
  11 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-07', 
  8 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-08', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-10', 
  12 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-11', 
  4 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-13', 
  2 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-15', 
  5 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-17', 
  9 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-19', 
  12 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-22', 
  3 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-28', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  48, 
  '2018-08-30', 
  8 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-01', 
  4 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-02', 
  8 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-03', 
  10 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-04', 
  5 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-05', 
  8 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-06', 
  12 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-07', 
  1 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-11', 
  12 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-14', 
  10 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-18', 
  10 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-19', 
  6 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-20', 
  12 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-22', 
  2 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-23', 
  3 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-26', 
  2 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  49, 
  '2018-08-30', 
  6 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-03', 
  4 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-04', 
  12 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-12', 
  1 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-15', 
  9 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-16', 
  7 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-17', 
  12 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-20', 
  5 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-21', 
  10 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-23', 
  1 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-24', 
  11 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-28', 
  2 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-29', 
  2 

EXECUTE dbo.Insert_student_marks 
  50, 
  '2018-08-30', 
  2 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-01', 
  8 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-04', 
  11 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-05', 
  4 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-11', 
  6 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-15', 
  1 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-20', 
  9 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-21', 
  2 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-23', 
  11 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-27', 
  3 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-28', 
  12 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-29', 
  5 

EXECUTE dbo.Insert_student_marks 
  51, 
  '2018-08-30', 
  5 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-03', 
  11 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-05', 
  3 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-06', 
  9 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-10', 
  6 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-13', 
  6 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-18', 
  7 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-23', 
  4 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-24', 
  5 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-25', 
  4 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-26', 
  11 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-28', 
  11 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-29', 
  3 

EXECUTE dbo.Insert_student_marks 
  52, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-03', 
  7 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-04', 
  3 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-06', 
  8 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-07', 
  3 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-08', 
  11 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-09', 
  5 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-10', 
  8 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-11', 
  10 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-12', 
  4 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-14', 
  9 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-15', 
  2 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-18', 
  3 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-19', 
  7 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-20', 
  11 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-22', 
  5 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-24', 
  2 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-27', 
  1 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-28', 
  4 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  53, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-02', 
  12 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-03', 
  5 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-06', 
  2 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-07', 
  2 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-08', 
  5 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-09', 
  8 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-13', 
  5 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-14', 
  5 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-15', 
  7 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-16', 
  12 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-17', 
  3 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-19', 
  8 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-22', 
  7 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-24', 
  3 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-25', 
  11 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-26', 
  9 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  54, 
  '2018-08-30', 
  9 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-01', 
  5 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-03', 
  12 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-04', 
  4 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-05', 
  10 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-06', 
  6 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-07', 
  9 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-08', 
  9 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-09', 
  4 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-10', 
  5 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-14', 
  12 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-17', 
  1 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-19', 
  4 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-20', 
  4 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-21', 
  8 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-23', 
  10 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-27', 
  9 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  55, 
  '2018-08-30', 
  10 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-02', 
  2 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-03', 
  8 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-05', 
  7 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-07', 
  4 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-09', 
  1 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-10', 
  7 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-12', 
  11 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-13', 
  1 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-14', 
  11 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-15', 
  11 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-17', 
  11 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-18', 
  9 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-19', 
  1 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-20', 
  1 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-21', 
  9 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-22', 
  4 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-23', 
  8 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-25', 
  5 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-26', 
  1 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-27', 
  11 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-29', 
  12 

EXECUTE dbo.Insert_student_marks 
  56, 
  '2018-08-30', 
  4 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-01', 
  6 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-02', 
  9 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-03', 
  6 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-04', 
  9 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-05', 
  1 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-06', 
  10 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-08', 
  2 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-10', 
  9 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-11', 
  7 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-12', 
  5 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-13', 
  10 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-15', 
  4 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-16', 
  2 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-17', 
  5 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-18', 
  11 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-20', 
  10 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-21', 
  11 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-22', 
  12 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-23', 
  9 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-24', 
  8 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-25', 
  3 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-26', 
  5 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-28', 
  8 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-29', 
  11 

EXECUTE dbo.Insert_student_marks 
  57, 
  '2018-08-30', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-01', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-02', 
  7 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-03', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-04', 
  2 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-05', 
  11 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-06', 
  11 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-07', 
  8 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-08', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-10', 
  12 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-11', 
  4 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-12', 
  10 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-13', 
  2 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-14', 
  8 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-15', 
  5 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-16', 
  5 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-17', 
  9 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-18', 
  12 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-19', 
  12 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-20', 
  3 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-21', 
  4 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-22', 
  3 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-23', 
  5 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-24', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-25', 
  9 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-27', 
  7 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-28', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-29', 
  1 

EXECUTE dbo.Insert_student_marks 
  58, 
  '2018-08-30', 
  8 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-01', 
  4 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-02', 
  8 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-03', 
  10 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-04', 
  5 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-05', 
  8 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-06', 
  12 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-07', 
  1 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-08', 
  6 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-09', 
  11 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-11', 
  12 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-12', 
  8 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-13', 
  3 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-14', 
  10 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-15', 
  10 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-16', 
  9 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-17', 
  7 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-18', 
  10 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-19', 
  6 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-20', 
  12 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-21', 
  7 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-22', 
  2 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-23', 
  3 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-24', 
  7 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-25', 
  10 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-26', 
  2 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-28', 
  7 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-29', 
  4 

EXECUTE dbo.Insert_student_marks 
  59, 
  '2018-08-30', 
  6 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-01', 
  7 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-02', 
  6 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-03', 
  4 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-04', 
  12 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-05', 
  2 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-06', 
  4 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-07', 
  7 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-08', 
  3 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-09', 
  12 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-10', 
  3 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-11', 
  8 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-12', 
  1 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-13', 
  9 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-14', 
  7 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-15', 
  9 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-16', 
  7 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-17', 
  12 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-18', 
  4 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-19', 
  11 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-20', 
  5 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-21', 
  10 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-22', 
  10 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-23', 
  1 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-24', 
  11 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-25', 
  8 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-26', 
  10 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-27', 
  2 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-28', 
  2 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-29', 
  2 

EXECUTE dbo.Insert_student_marks 
  60, 
  '2018-08-30', 
  2 