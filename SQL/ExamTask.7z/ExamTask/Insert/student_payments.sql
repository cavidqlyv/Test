USE examtask 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  1 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  2 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  3 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  4 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  5 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  6 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  7 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  8 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  9 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  10 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  11 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  12 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  13 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  14 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  15 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  16 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  17 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  18 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  19 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  20 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  21 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  22 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  23 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  24 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  25 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  26 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  27 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  28 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  29 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  30 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  31 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  32 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  33 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  34 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  35 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  36 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  37 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  38 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  39 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  40 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  41 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  42 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  43 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  44 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  45 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  46 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  47 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  48 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  49 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  50 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  51 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  52 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  53 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  54 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  55 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  56 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  57 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  58 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  59 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-01-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-02-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-03-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-04-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-05-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-06-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-07-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_payments 
  60 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  1, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  2, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  3, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  4, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  5, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  6, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  7, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  8, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  9, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  10, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  11, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  12, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  13, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  14, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  15, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  16, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  17, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  18, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  19, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  20, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  21, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  22, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  23, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  24, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  25, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  26, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  27, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  28, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  29, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  30, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  31, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  32, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  33, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  34, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  35, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  36, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  37, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  38, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  39, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  40, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  41, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  42, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  43, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  44, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  45, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  46, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  47, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  48, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  49, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  50, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  51, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  52, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  53, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  54, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  55, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  56, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  57, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  58, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  59, 
  -1, 
  '2017-12-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-01-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-02-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-03-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-04-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-05-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-06-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-07-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-08-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-09-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-10-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-11-19' 

EXECUTE dbo.Insert_student_payments 
  60, 
  -1, 
  '2017-12-19' 

SELECT * 
FROM   student_payments 