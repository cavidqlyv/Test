USE examtask

EXECUTE dbo.Insert_lesson 
  'Desktop Support Technician', 
  300; 

EXECUTE dbo.Insert_lesson 
  'Marketing Assistant', 
  350; 

EXECUTE dbo.Insert_lesson 
  'Environmental Specialist', 
  550; 

EXECUTE dbo.Insert_lesson 
  'Food Chemist', 
  200; 

EXECUTE dbo.Insert_lesson 
  'Financial Advisor', 
  300; 

EXECUTE dbo.Insert_lesson 
  'Administrative Assistant I', 
  250; 

EXECUTE dbo.Insert_lesson 
  'Technical Writer', 
  650; 

EXECUTE dbo.Insert_lesson 
  'Senior Cost Accountant', 
  750; 

EXECUTE dbo.Insert_lesson 
  'Recruiting Manager', 
  350; 

EXECUTE dbo.Insert_lesson 
  'Chemical Engineer', 
  150; 

EXECUTE dbo.Insert_lesson 
  'Senior Editor', 
  500; 

EXECUTE dbo.Insert_lesson 
  'Director of Sales', 
  400; 

EXECUTE dbo.Insert_lesson 
  'Assistant Professor', 
  300; 

EXECUTE dbo.Insert_lesson 
  'Financial Analyst', 
  200; 

EXECUTE dbo.Insert_lesson 
  'Developer IV', 
  250; 

EXECUTE dbo.Insert_lesson 
  'Legal Assistant', 
  550; 

EXECUTE dbo.Insert_lesson 
  'VP Quality Control', 
  400; 

EXECUTE dbo.Insert_lesson 
  'Operator', 
  500; 

EXECUTE dbo.Insert_lesson 
  'Recruiter', 
  600; 

EXECUTE dbo.Insert_lesson 
  'Mechanical Systems Engineer', 
  700; 

SELECT * 
FROM   lesson 