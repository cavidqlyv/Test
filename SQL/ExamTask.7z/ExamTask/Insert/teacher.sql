USE examtask

EXECUTE dbo.Insert_teacher 
  'Lissie', 
  'Hull', 
  'lhull0@xing.com', 
  'lhull0', 
  'du0aALD'; 

EXECUTE dbo.Insert_teacher 
  'Forster', 
  'Phillins', 
  'fphillins1@ezinearticles.com', 
  'fphillins1', 
  'gUPDzLDT1aze'; 

EXECUTE dbo.Insert_teacher 
  'Burke', 
  'Bedo', 
  'bbedo2@rakuten.co.jp', 
  'bbedo2', 
  '9qFNUAHwAVN'; 

EXECUTE dbo.Insert_teacher 
  'Ingrid', 
  'Grote', 
  'igrote3@friendfeed.com', 
  'igrote3', 
  'AElZZCM'; 

EXECUTE dbo.Insert_teacher 
  'Emmaline', 
  'Greasty', 
  'egreasty4@jalbum.net', 
  'egreasty4', 
  'KLkboU7AzRq'; 

EXECUTE dbo.Insert_teacher 
  'Karl', 
  'Wilacot', 
  'kwilacot5@miitbeian.gov.cn', 
  'kwilacot5', 
  'FQqRE5A'; 

EXECUTE dbo.Insert_teacher 
  'Robinetta', 
  'Rikkard', 
  'rrikkard6@free.fr', 
  'rrikkard6', 
  'SH7Cz89T'; 

EXECUTE dbo.Insert_teacher 
  'Trixi', 
  'Yanukhin', 
  'tyanukhin7@hubpages.com', 
  'tyanukhin7', 
  'u0KXMIf'; 

EXECUTE dbo.Insert_teacher 
  'Denys', 
  'Davidwitz', 
  'ddavidwitz8@phoca.cz', 
  'ddavidwitz8', 
  '3G6uSKf9gFrj'; 

EXECUTE dbo.Insert_teacher 
  'Joanie', 
  'Duxbarry', 
  'jduxbarry9@oaic.gov.au', 
  'jduxbarry9', 
  'wKhGIuRdv'; 

EXECUTE dbo.Insert_teacher 
  'Leta', 
  'Elis', 
  'lelisa@dot.gov', 
  'lelisa', 
  'imeaLo0t'; 

EXECUTE dbo.Insert_teacher 
  'Buckie', 
  'Gourley', 
  'bgourleyb@ft.com', 
  'bgourleyb', 
  '3isXS4j1NKV'; 

EXECUTE dbo.Insert_teacher 
  'Antoine', 
  'Echallie', 
  'aechalliec@gizmodo.com', 
  'aechalliec', 
  'eQvvutDRT0'; 

EXECUTE dbo.Insert_teacher 
  'Juditha', 
  'Disbury', 
  'jdisburyd@facebook.com', 
  'jdisburyd', 
  'h49bAMX8AoN'; 

EXECUTE dbo.Insert_teacher 
  'Meier', 
  'Monteath', 
  'mmonteathe@princeton.edu', 
  'mmonteathe', 
  'D03nYet3Jv'; 

EXECUTE dbo.Insert_teacher 
  'Frances', 
  'Jobbins', 
  'fjobbinsf@blinklist.com', 
  'fjobbinsf', 
  'WTi1y4mxkNK0'; 

EXECUTE dbo.Insert_teacher 
  'Wiatt', 
  'Crothers', 
  'wcrothersg@acquirethisname.com', 
  'wcrothersg', 
  'H8K9Zf2G6mAk'; 

EXECUTE dbo.Insert_teacher 
  'Margaret', 
  'Blumer', 
  'mblumerh@yellowpages.com', 
  'mblumerh', 
  'ToolOg6'; 

EXECUTE dbo.Insert_teacher 
  'Lance', 
  'Hachard', 
  'lhachardi@paypal.com', 
  'lhachardi', 
  '0sHnfT'; 

EXECUTE dbo.Insert_teacher 
  'Luther', 
  'Staddon', 
  'lstaddonj@wikimedia.org', 
  'lstaddonj', 
  'BeNgaMx'; 

SELECT * 
FROM   teacher 