USE examtask 

SELECT * 
FROM   student_lessondays 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  1, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  2, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  3, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  4, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  5, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  6, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  7, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  8, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  9, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  10, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  11, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  12, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  13, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  14, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  15, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  16, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  17, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  18, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  19, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  20, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  21, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  22, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  23, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  24, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  25, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  26, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  27, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  28, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  29, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  30, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  31, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  32, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  33, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  34, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  35, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  36, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  37, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  38, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  39, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  40, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  41, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  42, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  43, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  44, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  45, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  46, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  47, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  48, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  49, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  50, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  51, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  52, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  53, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  54, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  55, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  56, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  57, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  58, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  59, 
  1, 
  '2018-08-30' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-01' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-02' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-03' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-04' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-05' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  0, 
  '2018-08-06' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-07' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-08' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-09' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-10' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  0, 
  '2018-08-11' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-12' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-13' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-14' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-15' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  0, 
  '2018-08-16' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-17' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-18' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-19' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-20' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  0, 
  '2018-08-21' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-22' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-23' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-24' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-25' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  0, 
  '2018-08-26' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-27' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-28' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  0, 
  '2018-08-29' 

EXECUTE dbo.Insert_student_lessonday 
  60, 
  1, 
  '2018-08-30' 

SELECT * 
FROM   student_lessondays 