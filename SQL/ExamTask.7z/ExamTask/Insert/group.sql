USE examtask 

EXECUTE dbo.Insert_group 
  'jivanyushin0', 
  16, 
  17; 

EXECUTE dbo.Insert_group 
  'dkytter1', 
  1, 
  10; 

EXECUTE dbo.Insert_group 
  'smularkey2', 
  1, 
  8; 

EXECUTE dbo.Insert_group 
  'lmullinger3', 
  15, 
  18; 

EXECUTE dbo.Insert_group 
  'kblackster4', 
  5, 
  19; 

EXECUTE dbo.Insert_group 
  'mandrasch5', 
  14, 
  1; 

EXECUTE dbo.Insert_group 
  'avallack6', 
  16, 
  16; 

EXECUTE dbo.Insert_group 
  'nbettleson7', 
  11, 
  11; 

EXECUTE dbo.Insert_group 
  'lhryskiewicz8', 
  7, 
  16; 

EXECUTE dbo.Insert_group 
  'msimion9', 
  7, 
  9; 

EXECUTE dbo.Insert_group 
  'hcopleya', 
  19, 
  2; 

EXECUTE dbo.Insert_group 
  'amcauslandb', 
  12, 
  16; 

EXECUTE dbo.Insert_group 
  'hjosefsonc', 
  5, 
  10; 

EXECUTE dbo.Insert_group 
  'ipearcyd', 
  8, 
  4; 

EXECUTE dbo.Insert_group 
  'jfiggene', 
  11, 
  5; 

EXECUTE dbo.Insert_group 
  'gcowf', 
  2, 
  16; 

EXECUTE dbo.Insert_group 
  'dfaireg', 
  11, 
  15; 

EXECUTE dbo.Insert_group 
  'jpawsonh', 
  16, 
  7; 

EXECUTE dbo.Insert_group 
  'cbottelli', 
  13, 
  19; 

EXECUTE dbo.Insert_group 
  'gbutlerj', 
  18, 
  12; 

EXECUTE dbo.Insert_group 
  'clormank', 
  2, 
  6; 

EXECUTE dbo.Insert_group 
  'lpachtal', 
  4, 
  10; 

EXECUTE dbo.Insert_group 
  'qgatesmanm', 
  20, 
  16; 

EXECUTE dbo.Insert_group 
  'aduboisn', 
  16, 
  11; 

EXECUTE dbo.Insert_group 
  'cpreono', 
  18, 
  10; 

EXECUTE dbo.Insert_group 
  'jdorotp', 
  7, 
  14; 

EXECUTE dbo.Insert_group 
  'vpesterfieldq', 
  3, 
  18; 

EXECUTE dbo.Insert_group 
  'nsawterr', 
  6, 
  15; 

EXECUTE dbo.Insert_group 
  'rfolkerds', 
  13, 
  7; 

EXECUTE dbo.Insert_group 
  'gdevanneyt', 
  14, 
  9; 

SELECT * 
FROM   [group] 

USE examtask
-- Get a list of tables and views in the current database
SELECT table_catalog [database], table_schema [schema], table_name name, table_type type
FROM INFORMATION_SCHEMA.TABLES
GO