USE examtask 

EXECUTE dbo.Insert_group_student 
  1, 
  1; 

EXECUTE dbo.Insert_group_student 
  2, 
  1; 

EXECUTE dbo.Insert_group_student 
  3, 
  1; 

EXECUTE dbo.Insert_group_student 
  4, 
  1; 

EXECUTE dbo.Insert_group_student 
  5, 
  1; 

EXECUTE dbo.Insert_group_student 
  6, 
  2; 

EXECUTE dbo.Insert_group_student 
  7, 
  2; 

EXECUTE dbo.Insert_group_student 
  8, 
  2; 

EXECUTE dbo.Insert_group_student 
  9, 
  2; 

EXECUTE dbo.Insert_group_student 
  10, 
  2; 

EXECUTE dbo.Insert_group_student 
  11, 
  3; 

EXECUTE dbo.Insert_group_student 
  12, 
  3; 

EXECUTE dbo.Insert_group_student 
  13, 
  3; 

EXECUTE dbo.Insert_group_student 
  14, 
  3; 

EXECUTE dbo.Insert_group_student 
  15, 
  3; 

EXECUTE dbo.Insert_group_student 
  16, 
  4; 

EXECUTE dbo.Insert_group_student 
  17, 
  4; 

EXECUTE dbo.Insert_group_student 
  18, 
  4; 

EXECUTE dbo.Insert_group_student 
  19, 
  4; 

EXECUTE dbo.Insert_group_student 
  20, 
  4; 

EXECUTE dbo.Insert_group_student 
  21, 
  5; 

EXECUTE dbo.Insert_group_student 
  22, 
  5; 

EXECUTE dbo.Insert_group_student 
  23, 
  5; 

EXECUTE dbo.Insert_group_student 
  24, 
  5; 

EXECUTE dbo.Insert_group_student 
  25, 
  5; 

EXECUTE dbo.Insert_group_student 
  26, 
  6; 

EXECUTE dbo.Insert_group_student 
  27, 
  6; 

EXECUTE dbo.Insert_group_student 
  28, 
  6; 

EXECUTE dbo.Insert_group_student 
  29, 
  6; 

EXECUTE dbo.Insert_group_student 
  30, 
  6; 

EXECUTE dbo.Insert_group_student 
  31, 
  7; 

EXECUTE dbo.Insert_group_student 
  32, 
  7; 

EXECUTE dbo.Insert_group_student 
  33, 
  7; 

EXECUTE dbo.Insert_group_student 
  34, 
  7; 

EXECUTE dbo.Insert_group_student 
  35, 
  7; 

EXECUTE dbo.Insert_group_student 
  36, 
  8; 

EXECUTE dbo.Insert_group_student 
  37, 
  8; 

EXECUTE dbo.Insert_group_student 
  38, 
  8; 

EXECUTE dbo.Insert_group_student 
  39, 
  8; 

EXECUTE dbo.Insert_group_student 
  40, 
  8; 

EXECUTE dbo.Insert_group_student 
  41, 
  9; 

EXECUTE dbo.Insert_group_student 
  42, 
  9; 

EXECUTE dbo.Insert_group_student 
  43, 
  9; 

EXECUTE dbo.Insert_group_student 
  44, 
  9; 

EXECUTE dbo.Insert_group_student 
  45, 
  9; 

EXECUTE dbo.Insert_group_student 
  46, 
  10; 

EXECUTE dbo.Insert_group_student 
  47, 
  10; 

EXECUTE dbo.Insert_group_student 
  48, 
  10; 

EXECUTE dbo.Insert_group_student 
  49, 
  10; 

EXECUTE dbo.Insert_group_student 
  50, 
  10; 

EXECUTE dbo.Insert_group_student 
  51, 
  11; 

EXECUTE dbo.Insert_group_student 
  52, 
  11; 

EXECUTE dbo.Insert_group_student 
  53, 
  11; 

EXECUTE dbo.Insert_group_student 
  54, 
  11; 

EXECUTE dbo.Insert_group_student 
  55, 
  11; 

EXECUTE dbo.Insert_group_student 
  56, 
  12; 

EXECUTE dbo.Insert_group_student 
  57, 
  12; 

EXECUTE dbo.Insert_group_student 
  58, 
  12; 

EXECUTE dbo.Insert_group_student 
  59, 
  12; 

EXECUTE dbo.Insert_group_student 
  60, 
  12; 

SELECT * 
FROM   group_student 