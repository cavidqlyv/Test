﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace FtpExample
{
    class FtpRepository
    {
        private string ftpUrl = "ftp://waws-prod-db3-027.ftp.azurewebsites.windows.net/site/wwwroot";
        private NetworkCredential networkCredential = new NetworkCredential("fsda1611ru", "EdvM2tx3CmSt5MPl44ln2YarLPgZs42Yf3vQMEfFDvuQEcp25uN7uZwZj6kh");

        private FtpWebRequest ftpRequest;

        public string UploadFile(string localPath, string ftpFileName)
        {
            try
            {
                ftpRequest = (FtpWebRequest)WebRequest.Create($"{ftpUrl}/{ftpFileName}");
                ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
                ftpRequest.Credentials = networkCredential;
                ftpRequest.EnableSsl = true;

                byte[] buffer = File.ReadAllBytes(localPath);
                ftpRequest.ContentLength = buffer.Length;

                Stream requestStream = ftpRequest.GetRequestStream();
                requestStream.Write(buffer, 0, buffer.Length);
                requestStream.Close();

                FtpWebResponse ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                string statusDescription = ftpResponse.StatusDescription;
                ftpResponse.Close();

                return statusDescription;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<string> GetFileList()
        {
            try
            {
                ftpRequest = (FtpWebRequest)WebRequest.Create(ftpUrl);
                ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                ftpRequest.Credentials = networkCredential;
                ftpRequest.EnableSsl = true;

                FtpWebResponse response = (FtpWebResponse)ftpRequest.GetResponse();
                StreamReader streamReader = new StreamReader(response.GetResponseStream());

                List<string> directories = new List<string>();
                string line = streamReader.ReadLine();
                while (!string.IsNullOrEmpty(line))
                {
                    directories.Add(line);
                    line = streamReader.ReadLine();
                }
                response.Close();

                return directories;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string DownloadFile(string ftpFileName, string localDirPath)
        {
            try
            {
                ftpRequest = (FtpWebRequest)WebRequest.Create($"{ftpUrl}/{ftpFileName}");
                ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                ftpRequest.Credentials = networkCredential;
                ftpRequest.EnableSsl = true;

                FtpWebResponse response = (FtpWebResponse)ftpRequest.GetResponse();
                Stream responseStream = response.GetResponseStream();
                FileStream fs = new FileStream($"{localDirPath}{ftpFileName}", FileMode.Create);
                byte[] buffer = new byte[1000];
                int size = 0;
                do
                {
                    size = responseStream.Read(buffer, 0, buffer.Length);
                    fs.Write(buffer, 0, size);
                } while (size > 0);
                fs.Close();
                string statusDescription = response.StatusDescription;
                response.Close();
                return statusDescription;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
