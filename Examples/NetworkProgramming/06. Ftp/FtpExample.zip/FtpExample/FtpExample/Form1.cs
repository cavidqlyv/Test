﻿using System;
using System.IO;
using System.Windows.Forms;

namespace FtpExample
{
    public partial class Form1 : Form
    {
        private FtpRepository ftpRepository = new FtpRepository();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonChooseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxUploadPath.Text = fileDialog.FileName;
            }
        }

        private void buttonUpload_Click(object sender, EventArgs e)
        {
            FileInfo file = new FileInfo(textBoxUploadPath.Text);
            string statusDescrip = ftpRepository.UploadFile(file.FullName, file.Name);
            MessageBox.Show(statusDescrip);
        }

        private void buttonList_Click(object sender, EventArgs e)
        {
            listBoxFiles.DataSource = ftpRepository.GetFileList();
        }

        private void buttonDownload_Click(object sender, EventArgs e)
        {
            if (listBoxFiles.SelectedIndex != -1)
            {
                string statusDescrip = ftpRepository.DownloadFile(listBoxFiles.SelectedItem.ToString(), "");
                MessageBox.Show(statusDescrip);
            }
            else
            {
                MessageBox.Show("Choose file for download.");
            }
        }

        private void listBoxFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxFiles.SelectedIndex != -1)
            {
                textBoxDownloadPath.Text = listBoxFiles.SelectedItem.ToString();
            }
            else
            {
                textBoxDownloadPath.Text = String.Empty;
            }
        }
    }
}
