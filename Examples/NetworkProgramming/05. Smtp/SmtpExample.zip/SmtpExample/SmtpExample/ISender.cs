﻿namespace SmtpExample
{
    interface ISender
    {
        void Send(string to, string topic, string body, string file);
    }
}
