﻿using System;
using System.Net;
using System.Net.Mail;

namespace SmtpExample
{
    class Sender : ISender
    {
        private string host;
        private int port;
        private NetworkCredential networkCredential;

        public Sender(string host, int port, NetworkCredential networkCredential)
        {
            this.host = host;
            this.port = port;
            this.networkCredential = networkCredential;
        }

        public void Send(string to, string topic, string body, string file)
        {
            MailMessage mailMessage = new MailMessage(
                new MailAddress(networkCredential.UserName, "SmtpExampleApp"),
                new MailAddress(to)
                );
            mailMessage.Subject = topic;
            mailMessage.Body = body;
            if (!String.IsNullOrEmpty(file))
            {
                mailMessage.Attachments.Add(new Attachment(file));
            }

            SmtpClient smtp = new SmtpClient(host, port);
            smtp.Credentials = networkCredential;
            smtp.EnableSsl = true;
            smtp.Send(mailMessage);
        }
    }
}
