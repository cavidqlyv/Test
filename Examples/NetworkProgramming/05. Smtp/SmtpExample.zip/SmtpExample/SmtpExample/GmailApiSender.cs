﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Gmail.v1;
using Google.Apis.Gmail.v1.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using MimeKit;
using System;
using System.IO;
using System.Net.Mail;
using System.Text;
using System.Threading;

namespace SmtpExample
{
    class GmailApiSender : ISender
    {
        public void Send(string to, string topic, string body, string file)
        {
            try
            {
                // проверка аутентификации
                UserCredential credential;
                using (FileStream stream = new FileStream("client_secret.json", FileMode.Open, FileAccess.Read))
                {
                    string credPath = ".credentials/gmail-dotnet-quickstart.json";

                    credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                        GoogleClientSecrets.Load(stream).Secrets,
                        new string[] { GmailService.Scope.GmailSend, GmailService.Scope.GmailReadonly },
                        "user",
                        CancellationToken.None,
                        new FileDataStore(credPath, true)).Result;
                }

                GmailService service = new GmailService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = "Nastia Gmail Client",
                });

                UsersResource.GetProfileRequest getProfileRequest = new UsersResource.GetProfileRequest(service, "me");
                Profile profile = getProfileRequest.Execute();
                
                // отправка письма
                MailMessage mailMessage = new MailMessage(new MailAddress(profile.EmailAddress), new MailAddress(to));
                mailMessage.Subject = topic;
                mailMessage.Body = body;
                if (!String.IsNullOrEmpty(file))
                {
                    mailMessage.Attachments.Add(new Attachment(file));
                }

                Message message = new Message();
                message.Raw = MsgToBase64(mailMessage);
                var sendRequest = service.Users.Messages.Send(message, profile.EmailAddress);
                sendRequest.Execute();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string MsgToBase64(MailMessage mailMessage)
        {
            MimeMessage mimeMessage = MimeMessage.CreateFromMailMessage(mailMessage);
            byte[] inputBytes = Encoding.UTF8.GetBytes(mimeMessage.ToString());
            return Convert.ToBase64String(inputBytes);
        }

    }
}
