﻿using System;
using System.Net;
using System.Windows.Forms;

namespace SmtpExample
{
    public partial class Form1 : Form
    {
        ISender mailSender;

        public Form1()
        {
            InitializeComponent();
            mailSender = new Sender("smtp.gmail.com", 587, new NetworkCredential("your_gmail_login", "pswd"));
            //mailSender = new Sender("smtp.yandex.ru", 587, new NetworkCredential("your_yandex_login", "pswd"));
            //mailSender = new GmailApiSender();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            try
            {
                mailSender.Send(textBoxTo.Text, textBoxTopic.Text, richTextBoxBody.Text, textBoxFile.Text);
                MessageBox.Show("Sended");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxFile.Text = fileDialog.FileName;
            }
        }
    }
}
