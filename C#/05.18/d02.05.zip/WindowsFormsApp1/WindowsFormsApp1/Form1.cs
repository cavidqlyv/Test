﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<IUser> list = new List<IUser>();
        public Form1()
        {
            InitializeComponent();
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Regex regex1 = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$");
            if (regex.IsMatch(textBox1.Text) && regex1.IsMatch(textBox2.Text) && checkBox1.Checked)
            {
                if (comboBox1.Text == "Worker")
                {
                    list.Add(new Worker { Mail = textBox1.Text, Password = textBox2.Text });
                    Worker tmp = list.Last() as Worker;
                    MessageBox.Show("Worker" + tmp.Mail);
                }
                else
                {
                    list.Add(new Employer { Mail = textBox1.Text, Password = textBox2.Text });
                    Employer tmp = list.Last() as Employer;
                    MessageBox.Show("Worker" + tmp.Mail);
                }

            }
            else
                MessageBox.Show("Error");
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (comboBox1.Text.Length != 0 && checkBox1.Checked && textBox1.Text.Length != 0 && textBox2.Text.Length != 0)
                if (e.KeyCode == Keys.Enter)
                    button1.PerformClick();
        }
    }
    interface IUser
    {
        string Mail { get; set; }
        string Password { get; set; }

    }
    abstract class User : IUser
    {
        public string Mail { get; set; }
        public string Password { get; set; }
    }

    class Worker : User
    {

    }
    class Employer : User
    {

    }
}
