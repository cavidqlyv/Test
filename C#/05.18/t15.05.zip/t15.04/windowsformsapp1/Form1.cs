﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<Doctor> Pediatriya = new List<Doctor>
        {
            new Doctor{Name = "qqqq" , Surname = "wwww"},
            new Doctor{Name = "eeee" , Surname = "rrrr"},
            new Doctor{Name = "tttt" , Surname = "yyyy"}
        };
        List<Doctor> Travmatologiya = new List<Doctor>
        {
            new Doctor{Name = "uuuu" , Surname = "iiii"},
            new Doctor{Name = "oooo" , Surname = "pppp"},
            new Doctor{Name = "aaaa" , Surname = "ssss"}
        };
        List<Doctor> Stamotologiya = new List<Doctor>
        {
            new Doctor{Name = "dddd" , Surname = "ffff"},
            new Doctor{Name = "gggg" , Surname = "hhhh"},
            new Doctor{Name = "jjjj" , Surname = "kkkk"}
        };
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // dateTimePicker1.MinDate = DateTime.Now;
            monthCalendar1.MinDate = DateTime.Now;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            foreach (var item in Pediatriya)
            {
                comboBox1.Items.Add(item.Name + " " + item.Surname);
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            foreach (var item in Travmatologiya)
            {
                comboBox1.Items.Add(item.Name + " " + item.Surname);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            foreach (var item in Stamotologiya)
            {
                comboBox1.Items.Add(item.Name + " " + item.Surname);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Doctor tmp = null;
            if (radioButton1.Checked)
            {
                tmp = FindDoctor(Pediatriya);
            }
            else if (radioButton2.Checked)
            {
                tmp = FindDoctor(Travmatologiya);
            }
            else if (radioButton3.Checked)
            {
                tmp = FindDoctor(Stamotologiya);
            }
            if (tmp == null)
            {
                MessageBox.Show(comboBox1.Text);
                return;
            }
            monthCalendar1.BoldedDates = tmp.Times.ToArray();
            //foreach (var item in tmp.Times)
            //{
            //    monthCalendar1.AddBoldedDate(item);
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1 != null && textBox2 != null && textBox3 != null && textBox4 != null && monthCalendar1.SelectionRange.Start != null && comboBox1.SelectedText != null)
            {
                Doctor tmp = null;
                if (radioButton1.Checked)
                {
                    tmp = FindDoctor(Pediatriya);
                }
                else if (radioButton2.Checked)
                {
                    tmp = FindDoctor(Travmatologiya);
                }
                else if (radioButton3.Checked)
                {
                    tmp = FindDoctor(Stamotologiya);
                }
                tmp.Times.Add(new DateTime(monthCalendar1.SelectionRange.Start.Year, monthCalendar1.SelectionRange.Start.Month , monthCalendar1.SelectionRange.Start.Day));
                MessageBox.Show("OK!");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                comboBox1.Items.Clear();
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                
            }
        }

        private Doctor FindDoctor(List<Doctor> list)
        {
            foreach (var item in list)
            {
                if (item.Name + " " + item.Surname == comboBox1.Text)
                {
                    return item;
                }
            }
            return null;
        }


    }
    class Doctor
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        private List<DateTime> times = new List<DateTime>();
        public List<DateTime> Times { get => times; set => times = value; }
    }

}
