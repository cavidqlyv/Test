﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (button.BackColor == SystemColors.Control)
                button.BackColor = Color.Red;
            else if (button.BackColor == Color.Green)
                MessageBox.Show("Error");
            else if (button.BackColor == Color.Red)
                button.BackColor = SystemColors.Control;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            var a = Controls.OfType<Button>().ToList();
            foreach (var item in a)
                if (item.BackColor == Color.Red)
                    item.BackColor = Color.Green;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
        }
    }
}
