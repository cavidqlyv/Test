﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp16
{
    public partial class Form1 : Form
    {
        List<User> list = new List<User>();
        public Form1()
        {


            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            list.Add(new User { Username = textBox1.Text, Password = textBox2.Text });
            panel2.Visible = true;
            listView1.Items.Clear();
            foreach (var item in list)
            {
                listView1.Items.Add(new ListViewItem(new string[] { item.Username, item.Password }));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }
    }
    class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

}
