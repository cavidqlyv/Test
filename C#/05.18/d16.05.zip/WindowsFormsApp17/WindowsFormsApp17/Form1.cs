﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\2.png");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\1.png");

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\1.png");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\3.jpg");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\4.png");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\5.png");

        }
    }
}
