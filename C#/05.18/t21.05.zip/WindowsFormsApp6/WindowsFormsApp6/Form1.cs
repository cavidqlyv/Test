﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        char lastOperation;
        double value = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            textBox1.Text += button.Text;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            lastOperation = '+';
            try
            {
                if (value == 0)
                {
                    value = Convert.ToDouble(textBox1.Text);
                    label1.Text = textBox1.Text;
                    textBox1.Clear();
                }
                else
                {
                    value += Convert.ToDouble(textBox1.Text);
                    label1.Text = value.ToString();
                    textBox1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //   button1.form = FormBorderStyle.None;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            lastOperation = '-';
            try
            {
                if (value == 0)
                {
                    value = Convert.ToDouble(textBox1.Text);
                    label1.Text = textBox1.Text;
                    textBox1.Clear();
                }
                else
                {
                    value -= Convert.ToDouble(textBox1.Text);
                    label1.Text = value.ToString();
                    textBox1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            lastOperation = '*';
            try
            {
                if (value == 0)
                {
                    value = Convert.ToDouble(textBox1.Text);
                    label1.Text = textBox1.Text;
                    textBox1.Clear();
                }
                else
                {
                    value *= Convert.ToDouble(textBox1.Text);
                    label1.Text = value.ToString();
                    textBox1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            lastOperation = '/';
            try
            {
                if (value == 0)
                {
                    value = Convert.ToDouble(textBox1.Text);
                    label1.Text = textBox1.Text;
                    textBox1.Clear();
                }
                else
                {
                    value /= Convert.ToDouble(textBox1.Text);
                    label1.Text = value.ToString();
                    textBox1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            value = 0;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                switch (lastOperation)
                {
                    case '+':
                        value += Convert.ToDouble(textBox1.Text);
                        break;
                    case '-':
                        value += Convert.ToDouble(textBox1.Text);
                        break;
                    case '*':
                        value += Convert.ToDouble(textBox1.Text);
                        break;
                    case '/':
                        value += Convert.ToDouble(textBox1.Text);
                        break;
                    default:
                        break;
                }
                textBox1.Text = value.ToString();
                label1.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            value = Convert.ToDouble(textBox1.Text);
            value *= value;
            label1.Text = value.ToString();
            textBox1.Clear();
        }
    }
}
