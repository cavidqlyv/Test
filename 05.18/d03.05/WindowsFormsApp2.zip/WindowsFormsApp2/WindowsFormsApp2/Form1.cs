﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int width = 50;
            int height = 50;
            bool flag = false;
            for (int i = 0; i < 64; i++)
            {
                Button button = new Button();
                button.Location = new System.Drawing.Point(width, height);
                button.Name = "button1";
                button.Size = new System.Drawing.Size(50, 50);
                button.TabIndex = 0;
                button.Text = "";
                button.UseVisualStyleBackColor = true;
                button.Click += Button_Click;
                Controls.Add(button);
                if (flag)
                {
                    button.BackColor = Color.White;
                    flag = false;
                }
                else
                {
                    button.BackColor = Color.Black;
                    flag = true;
                }
                width += 50;
                if (width == 450)
                {
                    width = 50;
                    height += 50;
                    if (flag)
                        flag = false;
                    else
                        flag = true;
                }
            }
            int widthL = 50;
            int heightL = 50;
            char c = (char)65;
            for (int i = 0; i < 8; i++)
            {
                Label label = new Label();
                label.AutoSize = true;
                label.Location = new Point(widthL, 0);
                label.Name = "label1";
                label.Size = new Size(50, 50);
                label.TabIndex = 0;
                label.Text = (i + 1).ToString();
                label.Font = new Font("Arial", 35);

                Label label1 = new Label();
                label1.AutoSize = true;
                label1.Location = new Point(0, heightL);
                label1.Name = "label1";
                label1.Size = new Size(50, 50);
                label1.TabIndex = 0;
                label1.Text = c.ToString();
                label1.Font = new Font("Arial", 35);

                c++;
                widthL += 50;
                heightL += 50;
                Controls.Add(label);
                Controls.Add(label1);

            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            MessageBox.Show(button.BackColor.ToString());
        }
    }
}
