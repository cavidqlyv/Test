namespace WindowsFormsApp20
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class DbEntity : DbContext
    {

        public DbEntity()
            : base("name=DbEntity")
        {
        }
        public virtual DbSet<Seller> SellerDb { get; set; }
        public virtual DbSet<Customer> CostumerDb { get; set; }
        public virtual DbSet<Order> OrderDb { get; set; }
        public virtual DbSet<Product> ProductDb { get; set; }
    }

}