﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp20
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null && textBox2.Text != null && textBox3.Text != null && textBox4.Text != null && textBox5.Text != null && textBox2.Text == textBox3.Text)
            {
                using (DbEntity db = new DbEntity())
                {
                    if (db.SellerDb.SingleOrDefault(x => x.Username == textBox1.Text) == null)
                    {
                        db.SellerDb.Add(new Seller { Username = textBox1.Text, Password = textBox2.Text, Name = textBox4.Text, Surname = textBox5.Text });
                        await db.SaveChangesAsync();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Change Username");
                    }
                }
            }
        }
    }
}
