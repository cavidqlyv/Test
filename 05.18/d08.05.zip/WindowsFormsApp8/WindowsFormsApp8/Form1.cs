﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        Form2 form2 = new Form2();
        Form3 form3 = new Form3();

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form2.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Data.Users.Count == 0)
                MessageBox.Show("Wrong Login or Password");
            bool flag = false;
            foreach (var item in Data.Users)
            {
                if (item.Username == textBox1.Text && item.Password == textBox2.Text)
                {
                    form3.ShowDialog();
                    flag = true;
                }
            }
            if (!flag)
                MessageBox.Show("Wrong Login or Password");
            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
