﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1 != null && textBox2 != null && textBox3 != null && textBox4 != null)
            {
                User user = new User
                {
                    Name = textBox1.Text,
                    Surname = textBox3.Text,
                    Username = textBox2.Text,
                    Password = textBox4.Text
                };
                Data.Users.Add(user);
                Close();
            }
            else
                MessageBox.Show("Error!");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();

        }
    }
}
