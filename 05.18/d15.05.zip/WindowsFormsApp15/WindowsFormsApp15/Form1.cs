﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp15
{
    public partial class Form1 : Form
    {
        List<Items> list = new List<Items>()
        {
            new Items{ID = "1" , Name = "aaaa" , Office = "ssss" , Position = "dddd"},
            new Items{ID = "2" , Name = "eeeae" , Office = "ffff" , Position = "gggg"},
            new Items{ID = "3" , Name = "hhahh" , Office = "qqqq" , Position = "kkpkk"},
            new Items{ID = "4" , Name = "llll" , Office = "qqqq" , Position = "wwww"},
            new Items{ID = "5" , Name = "eelee" , Office = "ffff" , Position = "tttt"},
            new Items{ID = "6" , Name = "yyyy" , Office = "ffff" , Position = "iiipi"}
        };
        List<Items> tmp = new List<Items>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (var item in list)
            {
                listView1.Items.Add(new ListViewItem(new string[] {item.ID, item.Name, item.Position , item.Office}));
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            if (textBox1.Text.Length != 0)
            {
                tmp.Clear();
                foreach (var item in list)
                {
                    if (item.ID.IndexOf(textBox1.Text) != -1 || item.Name.IndexOf(textBox1.Text) != -1 || item.Office.IndexOf(textBox1.Text) != -1 || item.Position.IndexOf(textBox1.Text) != -1)
                        tmp.Add(item);
                }
                foreach (var item in tmp)
                {
                    listView1.Items.Add(new ListViewItem(new string[] { item.ID, item.Name, item.Position, item.Office }));
                }
            }
            else
            {
                foreach (var item in list)
                    listView1.Items.Add(new ListViewItem(new string[] { item.ID, item.Name, item.Position, item.Office }));
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            listView1.Items.Clear();
            tmp.Clear();
            if (e.Column == 0)
                tmp = list.OrderBy(x => x.ID).ToList();
            else if (e.Column == 1)
                tmp = list.OrderBy(x => x.Name).ToList();
            else if (e.Column == 2)
                tmp = list.OrderBy(x => x.Position).ToList();
            else if (e.Column == 3)
                tmp = list.OrderBy(x => x.Office).ToList();

            foreach (var item in tmp)
                listView1.Items.Add(new ListViewItem(new string[] { item.ID, item.Name, item.Position, item.Office }));

            //   MessageBox.Show(e.Column.ToString());
        }
    }

    class Items
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string Office { get; set; }
    }
}
