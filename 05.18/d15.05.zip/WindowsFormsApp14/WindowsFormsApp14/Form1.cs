﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                var response = client.GetStringAsync(new Uri("https://api.openweathermap.org/data/2.5/weather?q=Baku,az&APPID=6263053c735881cfa8657d16f6af16ff&units=metric")).Result;
                Rootobject rootobject = JsonConvert.DeserializeObject<Rootobject>(response);
                label3.Text = rootobject.name;
                label4.Text = rootobject.main.temp.ToString();
                label10.Text = rootobject.wind.speed.ToString();
                label9.Text = rootobject.main.humidity.ToString();
                label8.Text = rootobject.sys.sunrise.ToString();
                if (rootobject.weather[0].description == "clear sky")
                    pictureBox1.Image = Image.FromFile(@"\\ITSTEP\students redirection$\sale_rv37\Desktop\download.jpg");
            }
        }
    }
    public class Rootobject
    {
        public Coord coord { get; set; }
        public Weather[] weather { get; set; }
        public string _base { get; set; }
        public Main main { get; set; }
        public int visibility { get; set; }
        public Wind wind { get; set; }
        public Clouds clouds { get; set; }
        public int dt { get; set; }
        public Sys sys { get; set; }
        public int id { get; set; }
        public string name { get; set; }
        public int cod { get; set; }
    }
    public class Coord
    {
        public float lon { get; set; }
        public float lat { get; set; }
    }

    public class Main
    {
        public int temp { get; set; }
        public int pressure { get; set; }
        public int humidity { get; set; }
        public int temp_min { get; set; }
        public int temp_max { get; set; }
    }

    public class Wind
    {
        public float speed { get; set; }
        public int deg { get; set; }
    }

    public class Clouds
    {
        public int all { get; set; }
    }

    public class Sys
    {
        public int type { get; set; }
        public int id { get; set; }
        public float message { get; set; }
        public string country { get; set; }
        public int sunrise { get; set; }
        public int sunset { get; set; }
    }

    public class Weather
    {
        public int id { get; set; }
        public string main { get; set; }
        public string description { get; set; }
        public string icon { get; set; }
    }
}
