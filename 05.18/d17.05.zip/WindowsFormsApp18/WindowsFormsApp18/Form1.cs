﻿using System;
using System.Collections.Generic;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            using (UserEntity db = new UserEntity())
            {
                db.Users.Add(new User { Username = textBox1.Text, Password = textBox2.Text });
                await db.SaveChangesAsync();
            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            using (UserEntity db = new UserEntity())
            {
                var user = db.Users.FirstOrDefault(x => x.Username == textBox3.Text);
                db.Users.Remove(user);

                await db.SaveChangesAsync();

            }
        }
    }
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
