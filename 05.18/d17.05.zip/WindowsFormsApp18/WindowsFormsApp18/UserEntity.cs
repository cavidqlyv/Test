namespace WindowsFormsApp18
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class UserEntity : DbContext
    {
        public UserEntity(): base("name=UserEntity")
        {

        }
        public virtual DbSet<User> Users { get; set; }
    }

}