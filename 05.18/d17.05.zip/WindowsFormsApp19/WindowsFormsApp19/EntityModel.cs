namespace WindowsFormsApp19
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class EntityModel : DbContext
    {
        public EntityModel()
            : base("name=Model1")
        {
        }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Department> Departaments { get; set; }

    }
}