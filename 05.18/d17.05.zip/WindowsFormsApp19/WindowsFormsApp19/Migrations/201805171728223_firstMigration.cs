namespace WindowsFormsApp19.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class firstMigration : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "department_Id", c => c.Int());
            CreateIndex("dbo.Users", "department_Id");
            AddForeignKey("dbo.Users", "department_Id", "dbo.Departments", "Id");
            DropColumn("dbo.Users", "DepartmentName");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Users", "DepartmentName", c => c.String());
            DropForeignKey("dbo.Users", "department_Id", "dbo.Departments");
            DropIndex("dbo.Users", new[] { "department_Id" });
            DropColumn("dbo.Users", "department_Id");
        }
    }
}
